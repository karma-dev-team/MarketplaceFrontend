export const AuthKey = "Authorization"
export const TempEmailKey = "tempEmail"
export const basePath = "http://localhost:8000"
export const baseDownloadPath = basePath + "/api/files/download/"