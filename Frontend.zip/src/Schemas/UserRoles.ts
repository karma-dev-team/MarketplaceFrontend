enum UserRoles {
    Other = "Other", 
    User = "User", 
    Seller = "Seller", 
    Moderator = "Moderator", 
    Admin = "Admin", 
    Owner = "Owner", 
    Superadmin = "Superadmin"
}

export default UserRoles; 