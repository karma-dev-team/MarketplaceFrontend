interface ImageScheme {
    id: string;
    filePath: string;
    stream?: string;
    fileName?: string;
    MimeType?: string;
}

export default ImageScheme; 