
export interface OptionType {
    value: string;
    label: string;
    icon?: string | undefined; 
}
