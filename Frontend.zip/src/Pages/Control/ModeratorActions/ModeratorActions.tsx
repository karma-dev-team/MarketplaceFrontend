const Page: React.FC = () => {  
    return (
        <div className="root-">
            
        </div>
    ); 
}

export default Page; 