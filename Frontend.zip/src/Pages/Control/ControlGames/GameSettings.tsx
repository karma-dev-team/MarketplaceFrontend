import { NavbarProps } from "src/Utils/NavbarProps";
import "./GameSettings.css"
import { StaffCategories } from "src/Schemas/Enums";
import { useState } from "react";
import StaffControlsComponent from "src/Components/StaffControls/StaffControls";

const GameSettingsPage: React.FC<NavbarProps> = (props: NavbarProps) => { 
    
    
    return (
        <div className="root-gamesettings">
            
            
        </div>
    )
}

export default GameSettingsPage; 